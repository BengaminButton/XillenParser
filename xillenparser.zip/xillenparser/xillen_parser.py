import sys
import os
import csv
import asyncio
import webbrowser
import sqlite3
import re
from datetime import datetime
from PyQt6.QtGui import QAction, QColor, QPalette, QBrush, QIcon, QPixmap, QPainter, QFont, QPolygonF
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QTableWidget, QTableWidgetItem, QAbstractItemView,
    QFileDialog, QMessageBox, QProgressBar, QHeaderView, QDialog, QListWidget,
    QListWidgetItem, QGroupBox, QGridLayout, QMenu, QStyleFactory, QTextBrowser
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSize, QPointF
from telethon.sync import TelegramClient
from telethon.tl.types import Message, User, Channel, Chat
from telethon.errors import SessionPasswordNeededError, FloodWaitError, RPCError

# ====================== НАСТРОЙКИ ТЕМ ======================
LIGHT_THEME = {
    "background": "#F5F7FF",
    "foreground": "#2C3E50",
    "accent": "#E3E8F9",
    "highlight": "#6A7BFF",
    "button": "#8A94CC",
    "button_hover": "#5A6BFF",
    "text": "#2C3E50",
    "success": "#4CAF50",
    "error": "#FF6B6B",
    "table_header": "#D6E0FF",
    "table_row_even": "#FFFFFF",
    "table_row_odd": "#F0F4FF",
    "dialog": "#FFFFFF",
    "input": "#FFFFFF",
    "input_text": "#000000",
    "link": "#5A67A8"
}

DARK_THEME = {
    "background": "#1E1E2E",
    "foreground": "#E0E0E0",
    "accent": "#2A2A3C",
    "highlight": "#6A7BFF",
    "button": "#5A67A8",
    "button_hover": "#4A57A8",
    "text": "#E0E0E0",
    "success": "#4CAF50",
    "error": "#FF6B6B",
    "table_header": "#2A2A4A",
    "table_row_even": "#252538",
    "table_row_odd": "#2D2D44",
    "dialog": "#2D2D44",
    "input": "#3A3A5A",
    "input_text": "#FFFFFF",
    "link": "#8A94CC"
}

# Выбор текущей темы по умолчанию
CURRENT_THEME = LIGHT_THEME

class AsyncTelegramWorker(QThread):
    update_progress = pyqtSignal(int, int, str)
    finished = pyqtSignal(list)
    error = pyqtSignal(str)
    phone_required = pyqtSignal()
    code_required = pyqtSignal()
    password_required = pyqtSignal()
    authorization_complete = pyqtSignal()
    chat_list_loaded = pyqtSignal(list)
    flood_wait = pyqtSignal(int)

    def __init__(self, session_path, api_id, api_hash, keyword, selected_chats=None):
        super().__init__()
        self.session_path = session_path
        self.api_id = api_id
        self.api_hash = api_hash
        self.keyword = keyword.lower() if keyword else ""
        self.results = []
        self.phone = None
        self.code = None
        self.password = None
        self.client = None
        self.selected_chats = selected_chats or []
        self.is_running = True

    def set_phone(self, phone):
        self.phone = phone

    def set_code(self, code):
        self.code = code

    def set_password(self, password):
        self.password = password

    def stop(self):
        self.is_running = False

    def run(self):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(self.main())
        loop.close()

    async def main(self):
        try:
            self.client = TelegramClient(
                self.session_path,
                self.api_id,
                self.api_hash,
                system_version='4.16.30-vxCUSTOM'
            )
            
            await self.client.connect()
            
            if not await self.client.is_user_authorized():
                # Запрашиваем номер телефона
                if not self.phone:
                    self.phone_required.emit()
                    while not self.phone and self.is_running:
                        await asyncio.sleep(0.5)
                    if not self.is_running:
                        return
                
                try:
                    # Отправляем запрос на код
                    await self.client.send_code_request(self.phone)
                except FloodWaitError as e:
                    self.flood_wait.emit(e.seconds)
                    return
                
                # Запрашиваем код
                if not self.code:
                    self.code_required.emit()
                    while not self.code and self.is_running:
                        await asyncio.sleep(0.5)
                    if not self.is_running:
                        return
                
                try:
                    # Пытаемся войти
                    await self.client.sign_in(self.phone, self.code)
                except SessionPasswordNeededError:
                    # Запрашиваем пароль
                    if not self.password:
                        self.password_required.emit()
                        while not self.password and self.is_running:
                            await asyncio.sleep(0.5)
                        if not self.is_running:
                            return
                    
                    # Входим с паролем
                    await self.client.sign_in(password=self.password)
            
            self.authorization_complete.emit()
            
            # Получаем список всех диалогов
            dialogs = await self.client.get_dialogs()
            dialogs = [d for d in dialogs if d.is_channel or d.is_group or d.is_user]
            
            # Если есть выбранные чаты - фильтруем диалоги
            if self.selected_chats:
                chat_ids = [int(chat.split(':')[0]) for chat in self.selected_chats]
                dialogs = [d for d in dialogs if d.entity.id in chat_ids]
            
            # Отправляем список чатов для отображения
            chat_list = [f"{d.entity.id}:{d.name}" for d in dialogs]
            self.chat_list_loaded.emit(chat_list)
            
            # Если нет ключевого слова - просто выходим
            if not self.keyword:
                self.finished.emit([])
                return
            
            total = len(dialogs)
            for index, dialog in enumerate(dialogs):
                if not self.is_running:
                    break
                    
                chat_name = dialog.name
                self.update_progress.emit(index + 1, total, f"Поиск в: {chat_name}")
                
                # Ищем сообщения с задержкой между запросами
                try:
                    async for message in self.client.iter_messages(dialog.entity, search=self.keyword):
                        if not self.is_running:
                            break
                            
                        if isinstance(message, Message) and message.text:
                            if self.keyword in message.text.lower():
                                date = message.date.strftime("%Y-%m-%d %H:%M:%S")
                                
                                # Получаем информацию об отправителе
                                sender = "Неизвестно"
                                if message.sender:
                                    if isinstance(message.sender, User):
                                        sender = message.sender.first_name
                                        if message.sender.last_name:
                                            sender += " " + message.sender.last_name
                                    elif isinstance(message.sender, (Channel, Chat)):
                                        sender = message.sender.title
                                
                                self.results.append({
                                    "chat": chat_name,
                                    "sender": sender,
                                    "date": date,
                                    "message": message.text
                                })
                except RPCError as e:
                    if "FLOOD_WAIT" in str(e):
                        match = re.search(r'FLOOD_WAIT_(\d+)', str(e))
                        if match:
                            wait_time = int(match.group(1))
                            self.flood_wait.emit(wait_time)
                    else:
                        self.error.emit(f"Ошибка в {chat_name}: {str(e)}")
                except sqlite3.OperationalError as e:
                    if "database is locked" in str(e):
                        print(f"Ignoring database locked error in {chat_name}")
                    else:
                        self.error.emit(f"Ошибка в {chat_name}: {str(e)}")
                except Exception as e:
                    self.error.emit(f"Ошибка в {chat_name}: {str(e)}")
            
            self.finished.emit(self.results)
        
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e):
                print("Ignoring database locked error")
            else:
                self.error.emit(f"Критическая ошибка: {str(e)}")
        except Exception as e:
            self.error.emit(f"Критическая ошибка: {str(e)}")
        finally:
            if self.client and self.client.is_connected():
                try:
                    await self.client.disconnect()
                except sqlite3.OperationalError as e:
                    if "database is locked" in str(e):
                        print("Ignoring database locked error on disconnect")
                    else:
                        raise
                except Exception as e:
                    print(f"Error during disconnect: {str(e)}")

class PhoneLoginDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Xillen Parser - Ввод номера")
        self.setFixedSize(400, 250)
        self.apply_theme()
        
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.setSpacing(20)
        
        # Логотип
        logo_label = QLabel()
        logo_pixmap = QPixmap(self.create_icon())
        logo_label.setPixmap(logo_pixmap)
        logo_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Текст
        text_label = QLabel("<h3>Авторизация в Telegram</h3><p>Пожалуйста, введите ваш номер телефона</p>")
        text_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        text_label.setStyleSheet(f"font-size: 12pt; color: {CURRENT_THEME['text']};")
        text_label.setWordWrap(True)
        
        # Поле ввода телефона
        self.phone_input = QLineEdit()
        self.phone_input.setPlaceholderText("+79123456789")
        
        # Кнопка
        self.submit_btn = QPushButton("Отправить")
        self.submit_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CURRENT_THEME['highlight']};
                color: white;
                border: none;
                padding: 10px;
                font-size: 12pt;
                border-radius: 4px;
            }}
            QPushButton:hover {{
                background-color: #5A6BFF;
            }}
        """)
        self.submit_btn.setFixedWidth(120)
        
        # Компоновка
        layout.addWidget(logo_label)
        layout.addWidget(text_label)
        layout.addWidget(self.phone_input)
        layout.addWidget(self.submit_btn, alignment=Qt.AlignmentFlag.AlignCenter)
        
        self.setLayout(layout)
    
    def create_icon(self):
        pixmap = QPixmap(80, 80)
        pixmap.fill(Qt.GlobalColor.transparent)
        painter = QPainter(pixmap)
        
        # Фон
        painter.setBrush(QBrush(QColor(CURRENT_THEME['highlight'])))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawRoundedRect(0, 0, 80, 80, 20, 20)
        
        # Буква X
        painter.setBrush(QBrush(QColor(CURRENT_THEME['background'])))
        points = [
            QPointF(30, 20), QPointF(40, 30), QPointF(50, 20), QPointF(60, 30),
            QPointF(50, 40), QPointF(60, 50), QPointF(50, 60), QPointF(40, 50),
            QPointF(30, 60), QPointF(20, 50), QPointF(30, 40), QPointF(20, 30)
        ]
        polygon = QPolygonF(points)
        painter.drawPolygon(polygon)
        
        painter.end()
        return pixmap
    
    def apply_theme(self):
        self.setStyleSheet(f"""
            background-color: {CURRENT_THEME['background']};
            color: {CURRENT_THEME['text']};
            font-family: Segoe UI, Arial;
            QLineEdit {{
                background-color: {CURRENT_THEME['input']};
                color: {CURRENT_THEME['input_text']};
                border: 1px solid #ccc;
                border-radius: 4px;
                padding: 10px;
                font-size: 14pt;
            }}
        """)

class CodeLoginDialog(QDialog):
    def __init__(self, is_password=False):
        super().__init__()
        self.setWindowTitle("Xillen Parser - Авторизация")
        self.setFixedSize(400, 250)
        self.apply_theme()
        
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.setSpacing(20)
        
        # Логотип
        logo_label = QLabel()
        logo_pixmap = QPixmap(self.create_icon())
        logo_label.setPixmap(logo_pixmap)
        logo_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Текст
        if is_password:
            text = "<h3>Двухфакторная аутентификация</h3><p>Пожалуйста, введите пароль вашего аккаунта</p>"
        else:
            text = "<h3>Авторизация в Telegram</h3><p>Пожалуйста, введите код из приложения Telegram</p>"
        
        text_label = QLabel(text)
        text_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        text_label.setStyleSheet(f"font-size: 12pt; color: {CURRENT_THEME['text']};")
        text_label.setWordWrap(True)
        
        # Поле ввода
        self.input_field = QLineEdit()
        self.input_field.setPlaceholderText("Пароль" if is_password else "Код")
        if is_password:
            self.input_field.setEchoMode(QLineEdit.EchoMode.Password)
        
        # Кнопка
        self.submit_btn = QPushButton("Отправить")
        self.submit_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CURRENT_THEME['highlight']};
                color: white;
                border: none;
                padding: 10px;
                font-size: 12pt;
                border-radius: 4px;
            }}
            QPushButton:hover {{
                background-color: #5A6BFF;
            }}
        """)
        self.submit_btn.setFixedWidth(120)
        
        # Компоновка
        layout.addWidget(logo_label)
        layout.addWidget(text_label)
        layout.addWidget(self.input_field)
        layout.addWidget(self.submit_btn, alignment=Qt.AlignmentFlag.AlignCenter)
        
        self.setLayout(layout)

    def create_icon(self):
        pixmap = QPixmap(80, 80)
        pixmap.fill(Qt.GlobalColor.transparent)
        painter = QPainter(pixmap)
        
        # Фон
        painter.setBrush(QBrush(QColor(CURRENT_THEME['highlight'])))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawRoundedRect(0, 0, 80, 80, 20, 20)
        
        # Буква X
        painter.setBrush(QBrush(QColor(CURRENT_THEME['background'])))
        points = [
            QPointF(30, 20), QPointF(40, 30), QPointF(50, 20), QPointF(60, 30),
            QPointF(50, 40), QPointF(60, 50), QPointF(50, 60), QPointF(40, 50),
            QPointF(30, 60), QPointF(20, 50), QPointF(30, 40), QPointF(20, 30)
        ]
        polygon = QPolygonF(points)
        painter.drawPolygon(polygon)
        
        painter.end()
        return pixmap
    
    def apply_theme(self):
        self.setStyleSheet(f"""
            background-color: {CURRENT_THEME['background']};
            color: {CURRENT_THEME['text']};
            font-family: Segoe UI, Arial;
            QLineEdit {{
                background-color: {CURRENT_THEME['input']};
                color: {CURRENT_THEME['input_text']};
                border: 1px solid #ccc;
                border-radius: 4px;
                padding: 10px;
                font-size: 14pt;
            }}
        """)

class AddChatDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Добавить чат")
        self.setFixedSize(400, 300)
        self.apply_theme()
        
        layout = QVBoxLayout()
        layout.setSpacing(15)
        
        # Заголовок
        title = QLabel("Добавить чат вручную")
        title.setStyleSheet(f"font-size: 16pt; color: {CURRENT_THEME['highlight']}; font-weight: bold;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Поле для ID/username
        self.chat_id_input = QLineEdit()
        self.chat_id_input.setPlaceholderText("Введите ID чата или имя пользователя")
        
        # Поле для названия
        self.chat_name_input = QLineEdit()
        self.chat_name_input.setPlaceholderText("Введите название чата (опционально)")
        
        # Кнопка добавления
        self.add_btn = QPushButton("Добавить чат")
        self.add_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CURRENT_THEME['highlight']};
                color: white;
                border: none;
                padding: 10px;
                font-size: 12pt;
                border-radius: 4px;
            }}
            QPushButton:hover {{
                background-color: #5A6BFF;
            }}
        """)
        self.add_btn.clicked.connect(self.accept)
        
        # Компоновка
        layout.addWidget(title)
        layout.addWidget(QLabel("ID чата или имя пользователя:"))
        layout.addWidget(self.chat_id_input)
        layout.addWidget(QLabel("Название чата:"))
        layout.addWidget(self.chat_name_input)
        layout.addWidget(self.add_btn)
        
        self.setLayout(layout)
    
    def apply_theme(self):
        self.setStyleSheet(f"""
            background-color: {CURRENT_THEME['background']};
            color: {CURRENT_THEME['text']};
            font-family: Segoe UI, Arial;
            QLineEdit {{
                background-color: {CURRENT_THEME['input']};
                color: {CURRENT_THEME['input_text']};
                border: 1px solid #ccc;
                border-radius: 4px;
                padding: 10px;
                font-size: 12pt;
            }}
        """)
    
    def get_chat_info(self):
        chat_id = self.chat_id_input.text().strip()
        chat_name = self.chat_name_input.text().strip() or chat_id
        return f"{chat_id}:{chat_name}"

class TutorialDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Руководство пользователя")
        self.setGeometry(100, 100, 800, 600)
        self.apply_theme()
        
        layout = QVBoxLayout()
        
        # Заголовок
        title = QLabel("Руководство пользователя Xillen Parser")
        title.setStyleSheet(f"font-size: 20pt; color: {CURRENT_THEME['highlight']}; font-weight: bold;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        
        # Текст руководства
        tutorial_text = QTextBrowser()
        tutorial_text.setOpenExternalLinks(True)
        tutorial_text.setStyleSheet(f"""
            background-color: {CURRENT_THEME['dialog']};
            color: {CURRENT_THEME['text']};
            border: none;
            border-radius: 8px;
            padding: 15px;
            font-size: 12pt;
        """)
        
        tutorial_content = """
        <h2>Добро пожаловать в Xillen Parser!</h2>
        <p>Это руководство поможет вам начать работу с программой для поиска сообщений в Telegram.</p>
        
        <h3>Шаг 1: Получение API ключей</h3>
        <p>Для работы программы вам необходимо получить API ID и API HASH на сайте <a href="https://my.telegram.org/apps">my.telegram.org</a>:</p>
        <ol>
            <li>Войдите в свой аккаунт Telegram</li>
            <li>Перейдите в раздел "API development tools"</li>
            <li>Создайте новое приложение и скопируйте API ID и API HASH</li>
        </ol>
        
        <h3>Шаг 2: Настройка программы</h3>
        <p>В главном окне программы:</p>
        <ul>
            <li>Введите полученные API ID и API HASH</li>
            <li>Введите ключевое слово для поиска</li>
            <li>Выберите чаты для поиска (или оставьте пустым для поиска по всем чатам)</li>
        </ul>
        
        <h3>Шаг 3: Авторизация</h3>
        <p>При первом запуске потребуется авторизация в Telegram:</p>
        <ol>
            <li>Введите номер телефона в формате +7XXXXXXXXXX</li>
            <li>Введите код из Telegram</li>
            <li>При необходимости введите пароль двухфакторной аутентификации</li>
        </ol>
        
        <h3>Шаг 4: Запуск поиска</h3>
        <p>Нажмите кнопку "Начать поиск" и дождитесь завершения процесса. Результаты будут отображены в таблице.</p>
        
        <h3>Шаг 5: Экспорт результатов</h3>
        <p>Вы можете экспортировать результаты в CSV или TXT формате с помощью соответствующих кнопок.</p>
        
        <h3>Советы</h3>
        <ul>
            <li>Для ускорения поиска выбирайте конкретные чаты вместо поиска по всем</li>
            <li>Используйте уникальные ключевые слова для точного поиска</li>
            <li>При возникновении ошибки флуда подождите указанное время</li>
            <li>Вы можете сменить тему оформления в меню "Вид"</li>
        </ul>
        
        <h3>Авторы</h3>
        <p>Разработчики программы:</p>
        <ul>
            <li><a href="https://t.me/BengaminButton">@BengaminButton</a></li>
            <li><a href="https://t.me/leshacoder">@LeshaCoder</a></li>
            <li><a href="https://t.me/xillenadapter">@XillenAdapter</a></li>
        </ul>
        """
        
        tutorial_text.setHtml(tutorial_content)
        layout.addWidget(tutorial_text)
        
        # Кнопка закрытия
        close_btn = QPushButton("Закрыть")
        close_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CURRENT_THEME['highlight']};
                color: white;
                border: none;
                padding: 10px 20px;
                font-size: 12pt;
                border-radius: 6px;
            }}
            QPushButton:hover {{
                background-color: #5A6BFF;
            }}
        """)
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignCenter)
        
        self.setLayout(layout)
    
    def apply_theme(self):
        self.setStyleSheet(f"""
            background-color: {CURRENT_THEME['background']};
            color: {CURRENT_THEME['text']};
            font-family: Segoe UI, Arial;
        """)

class XillenParser(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Xillen Parser")
        self.setGeometry(100, 100, 1200, 800)
        self.setWindowIcon(QIcon(self.create_icon()))
        
        # Основной виджет
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout()
        main_layout.setSpacing(20)
        main_layout.setContentsMargins(30, 30, 30, 30)
        main_widget.setLayout(main_layout)
        
        # Создание меню
        self.create_menu()
        
        # Заголовок
        header_layout = QHBoxLayout()
        
        # Логотип
        logo_label = QLabel()
        logo_pixmap = QPixmap(self.create_icon()).scaled(80, 80, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        logo_label.setPixmap(logo_pixmap)
        
        # Название
        title_label = QLabel("Xillen Parser")
        title_label.setStyleSheet(f"""
            color: {CURRENT_THEME['highlight']};
            font-size: 32pt;
            font-weight: bold;
            font-family: 'Segoe UI', Arial, sans-serif;
        """)
        
        # Авторы
        self.authors_label = QLabel()
        self.update_authors_label()
        self.authors_label.setOpenExternalLinks(True)
        self.authors_label.setStyleSheet(f"font-size: 10pt;")
        
        header_layout.addWidget(logo_label)
        header_layout.addWidget(title_label, stretch=1)
        header_layout.addWidget(self.authors_label, alignment=Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignBottom)
        
        # Поля ввода
        input_layout = QGridLayout()
        input_layout.setHorizontalSpacing(15)
        input_layout.setVerticalSpacing(10)
        
        # API поля
        input_layout.addWidget(QLabel("API ID:"), 0, 0)
        self.api_id_input = QLineEdit()
        self.api_id_input.setPlaceholderText("API ID")
        input_layout.addWidget(self.api_id_input, 0, 1)
        
        input_layout.addWidget(QLabel("API HASH:"), 0, 2)
        self.api_hash_input = QLineEdit()
        self.api_hash_input.setPlaceholderText("API HASH")
        input_layout.addWidget(self.api_hash_input, 0, 3)
        
        # Ключевое слово
        input_layout.addWidget(QLabel("Ключевое слово:"), 1, 0)
        self.keyword_input = QLineEdit()
        self.keyword_input.setPlaceholderText("Ключевое слово для поиска")
        input_layout.addWidget(self.keyword_input, 1, 1, 1, 3)
        
        # Группа для добавления чатов
        chat_group = QGroupBox("Выбор чатов")
        chat_group.setStyleSheet(f"""
            QGroupBox {{
                font-size: 12pt;
                font-weight: bold;
                color: {CURRENT_THEME['highlight']};
                border: 2px solid {CURRENT_THEME['highlight']};
                border-radius: 8px;
                margin-top: 20px;
                padding-top: 10px;
            }}
        """)
        chat_layout = QVBoxLayout()
        
        # Кнопки для работы с чатами
        chat_btn_layout = QHBoxLayout()
        
        self.add_chat_btn = QPushButton("Добавить чат вручную")
        self.add_chat_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CURRENT_THEME['button']};
                color: white;
                border: none;
                padding: 10px;
                font-size: 11pt;
                border-radius: 6px;
            }}
            QPushButton:hover {{
                background-color: #7A86CC;
            }}
        """)
        self.add_chat_btn.clicked.connect(self.add_chat_manually)
        
        self.load_all_btn = QPushButton("Загрузить все чаты")
        self.load_all_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CURRENT_THEME['highlight']};
                color: white;
                border: none;
                padding: 10px;
                font-size: 11pt;
                border-radius: 6px;
            }}
            QPushButton:hover {{
                background-color: #5A6BFF;
            }}
        """)
        self.load_all_btn.clicked.connect(self.load_all_chats)
        
        self.clear_chats_btn = QPushButton("Очистить выбор")
        self.clear_chats_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CURRENT_THEME['error']};
                color: white;
                border: none;
                padding: 10px;
                font-size: 11pt;
                border-radius: 6px;
            }}
            QPushButton:hover {{
                background-color: #FF5555;
            }}
        """)
        self.clear_chats_btn.clicked.connect(self.clear_chats)
        
        chat_btn_layout.addWidget(self.add_chat_btn)
        chat_btn_layout.addWidget(self.load_all_btn)
        chat_btn_layout.addWidget(self.clear_chats_btn)
        chat_btn_layout.addStretch()
        
        # Список чатов
        self.chats_list = QListWidget()
        self.chats_list.setSelectionMode(QListWidget.SelectionMode.MultiSelection)
        
        # Статус чатов
        self.chat_status = QLabel("Чаты не выбраны. Будет произведен поиск по всем чатам.")
        self.chat_status.setStyleSheet(f"color: {CURRENT_THEME['button']}; font-size: 10pt;")
        
        chat_layout.addLayout(chat_btn_layout)
        chat_layout.addWidget(self.chats_list)
        chat_layout.addWidget(self.chat_status)
        
        chat_group.setLayout(chat_layout)
        
        # Кнопка поиска
        self.search_btn = QPushButton("Начать поиск")
        self.search_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CURRENT_THEME['highlight']};
                color: white;
                border: none;
                padding: 15px 30px;
                font-size: 14pt;
                font-weight: bold;
                border-radius: 8px;
            }}
            QPushButton:hover {{
                background-color: #5A6BFF;
            }}
            QPushButton:disabled {{
                background-color: {CURRENT_THEME['button']};
            }}
        """)
        self.search_btn.setFixedHeight(60)
        self.search_btn.clicked.connect(self.start_search)
        
        # Прогресс бар
        self.progress_bar = QProgressBar()
        self.progress_bar.setStyleSheet(f"""
            QProgressBar {{
                border: 2px solid {CURRENT_THEME['highlight']};
                border-radius: 8px;
                text-align: center;
                background: {CURRENT_THEME['dialog']};
                height: 25px;
                font-size: 12pt;
                color: {CURRENT_THEME['text']};
            }}
            QProgressBar::chunk {{
                background: {CURRENT_THEME['highlight']};
                border-radius: 6px;
            }}
        """)
        self.progress_bar.setVisible(False)
        
        # Таблица результатов
        self.results_table = QTableWidget()
        self.results_table.setColumnCount(4)
        self.results_table.setHorizontalHeaderLabels(["Чат", "Отправитель", "Дата", "Сообщение"])
        self.results_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.results_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.results_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.results_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.results_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.results_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.results_table.verticalHeader().setVisible(False)
        
        # Кнопки экспорта
        export_layout = QHBoxLayout()
        export_layout.setSpacing(15)
        
        self.export_csv_btn = QPushButton("Экспорт в CSV")
        self.export_csv_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CURRENT_THEME['button']};
                color: white;
                border: none;
                padding: 12px 20px;
                font-size: 12pt;
                border-radius: 6px;
            }}
            QPushButton:hover {{
                background-color: #7A86CC;
            }}
            QPushButton:disabled {{
                background-color: #cccccc;
            }}
        """)
        self.export_csv_btn.clicked.connect(self.export_csv)
        self.export_csv_btn.setEnabled(False)
        
        self.export_txt_btn = QPushButton("Экспорт в TXT")
        self.export_txt_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CURRENT_THEME['button']};
                color: white;
                border: none;
                padding: 12px 20px;
                font-size: 12pt;
                border-radius: 6px;
            }}
            QPushButton:hover {{
                background-color: #7A86CC;
            }}
            QPushButton:disabled {{
                background-color: #cccccc;
            }}
        """)
        self.export_txt_btn.clicked.connect(self.export_txt)
        self.export_txt_btn.setEnabled(False)
        
        export_layout.addStretch()
        export_layout.addWidget(self.export_csv_btn)
        export_layout.addWidget(self.export_txt_btn)
        export_layout.addStretch()
        
        # Статус
        self.status_label = QLabel("Готов к запуску поиска")
        self.status_label.setStyleSheet(f"color: {CURRENT_THEME['button']}; font-size: 11pt;")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Добавление элементов в основной лэйаут
        main_layout.addLayout(header_layout)
        main_layout.addLayout(input_layout)
        main_layout.addWidget(chat_group)
        main_layout.addWidget(self.search_btn)
        main_layout.addWidget(self.progress_bar)
        main_layout.addWidget(self.results_table, stretch=1)
        main_layout.addLayout(export_layout)
        main_layout.addWidget(self.status_label)
        
        # Переменные для авторизации
        self.worker = None
        self.login_dialog = None
        self.selected_chats = []
        
        # Настройка пути к сессии
        self.session_path = "xillen_parser_session"
        if sys.platform == "linux":
            self.session_path = os.path.expanduser("~/xillen_session")
            
        # Применение темы ПОСЛЕ создания всех виджетов
        self.apply_theme()
        
        # Показываем туториал при первом запуске
        self.first_run = True
        if self.first_run:
            self.show_tutorial()
            self.first_run = False

    def update_authors_label(self):
        color = CURRENT_THEME['link']
        self.authors_label.setText(f"""
            <a href="https://t.me/BengaminButton" style="color: {color};">@BengaminButton</a> 
            <a href="https://t.me/leshacoder" style="color: {color};">@LeshaCoder</a> 
            <a href="https://t.me/xillenadapter" style="color: {color};">@XillenAdapter</a>
        """)

    def create_menu(self):
        menu_bar = self.menuBar()
        
        # Меню Файл
        file_menu = menu_bar.addMenu("Файл")
        
        exit_action = QAction("Выход", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Меню Вид
        view_menu = menu_bar.addMenu("Вид")
        
        light_theme_action = QAction("Светлая тема", self)
        light_theme_action.triggered.connect(lambda: self.set_theme('light'))
        view_menu.addAction(light_theme_action)
        
        dark_theme_action = QAction("Тёмная тема", self)
        dark_theme_action.triggered.connect(lambda: self.set_theme('dark'))
        view_menu.addAction(dark_theme_action)
        
        # Меню Помощь
        help_menu = menu_bar.addMenu("Помощь")
        
        guide_action = QAction("Руководство", self)
        guide_action.triggered.connect(self.show_tutorial)
        help_menu.addAction(guide_action)
        
        about_action = QAction("О программе", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)

    def apply_theme(self):
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(CURRENT_THEME['background']))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(CURRENT_THEME['text']))
        palette.setColor(QPalette.ColorRole.Base, QColor(CURRENT_THEME['dialog']))
        palette.setColor(QPalette.ColorRole.AlternateBase, QColor(CURRENT_THEME['accent']))
        palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(CURRENT_THEME['dialog']))
        palette.setColor(QPalette.ColorRole.ToolTipText, QColor(CURRENT_THEME['text']))
        palette.setColor(QPalette.ColorRole.Text, QColor(CURRENT_THEME['text']))
        palette.setColor(QPalette.ColorRole.Button, QColor(CURRENT_THEME['button']))
        palette.setColor(QPalette.ColorRole.ButtonText, QColor("white"))
        palette.setColor(QPalette.ColorRole.Highlight, QColor(CURRENT_THEME['highlight']))
        palette.setColor(QPalette.ColorRole.HighlightedText, QColor("white"))
        self.setPalette(palette)
        
        # Обновляем стили для всех виджетов
        self.setStyleSheet(f"""
            QWidget {{
                background-color: {CURRENT_THEME['background']};
                color: {CURRENT_THEME['text']};
                font-family: Segoe UI, Arial;
            }}
            QLabel {{
                color: {CURRENT_THEME['text']};
            }}
            QLineEdit {{
                background-color: {CURRENT_THEME['input']};
                color: {CURRENT_THEME['input_text']};
                border: 1px solid #ccc;
                border-radius: 4px;
                padding: 5px;
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                subcontrol-position: top center;
                padding: 0 5px;
            }}
            QListWidget {{
                background-color: {CURRENT_THEME['dialog']};
                color: {CURRENT_THEME['text']};
                border: 1px solid #ccc;
                border-radius: 6px;
                font-size: 11pt;
            }}
            QLabel a {{
                color: {CURRENT_THEME['link']};
                text-decoration: none;
            }}
            QLabel a:hover {{
                text-decoration: underline;
            }}
        """)
        
        # Обновляем таблицу
        self.apply_table_theme()
        self.update_authors_label()

    def apply_table_theme(self):
        self.results_table.setStyleSheet(f"""
            QTableWidget {{
                background-color: {CURRENT_THEME['background']};
                color: {CURRENT_THEME['text']};
                gridline-color: #e0e0e0;
                font-size: 11pt;
                border-radius: 8px;
                border: 1px solid #ddd;
                alternate-background-color: {CURRENT_THEME['table_row_odd']};
            }}
            QHeaderView::section {{
                background-color: {CURRENT_THEME['table_header']};
                color: {CURRENT_THEME['text']};
                padding: 4px;
                border: 1px solid #ddd;
                font-weight: bold;
            }}
        """)
        self.results_table.setAlternatingRowColors(True)

    def set_theme(self, theme_name):
        global CURRENT_THEME
        if theme_name == 'light':
            CURRENT_THEME = LIGHT_THEME
        else:
            CURRENT_THEME = DARK_THEME
        
        self.apply_theme()
        
        # Обновляем диалоги, если они открыты
        if hasattr(self, 'login_dialog') and self.login_dialog:
            self.login_dialog.apply_theme()

    def create_icon(self):
        # Генерация логотипа Xillen Parser
        pixmap = QPixmap(256, 256)
        pixmap.fill(Qt.GlobalColor.transparent)
        painter = QPainter(pixmap)
        
        # Фон
        painter.setBrush(QBrush(QColor(CURRENT_THEME['highlight'])))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawRoundedRect(0, 0, 256, 256, 60, 60)
        
        # Буква X
        painter.setBrush(QBrush(QColor(CURRENT_THEME['background'])))
        points = [
            QPointF(80, 60), QPointF(128, 108), QPointF(176, 60), QPointF(196, 80),
            QPointF(148, 128), QPointF(196, 176), QPointF(176, 196), QPointF(128, 148),
            QPointF(80, 196), QPointF(60, 176), QPointF(108, 128), QPointF(60, 80)
        ]
        polygon = QPolygonF(points)
        painter.drawPolygon(polygon)
        
        # Текст
        painter.setPen(QColor("white"))
        painter.setFont(QFont("Segoe UI", 24, QFont.Weight.Bold))
        painter.drawText(0, 220, 256, 30, Qt.AlignmentFlag.AlignCenter, "Xillen")
        
        painter.end()
        return pixmap

    def add_chat_manually(self):
        dialog = AddChatDialog()
        if dialog.exec() == QDialog.DialogCode.Accepted:
            chat_info = dialog.get_chat_info()
            self.selected_chats.append(chat_info)
            self.update_chats_list()
            self.chat_status.setText(f"Выбрано чатов: {len(self.selected_chats)}")

    def load_all_chats(self):
        api_id = self.api_id_input.text().strip()
        api_hash = self.api_hash_input.text().strip()
        
        if not api_id or not api_hash:
            self.show_error("Пожалуйста, введите API ID и API HASH")
            return
            
        self.status_label.setText("Загрузка списка чатов...")
        self.status_label.setStyleSheet(f"color: {CURRENT_THEME['button']};")
        
        # Запуск потока для загрузки чатов
        self.worker = AsyncTelegramWorker(
            self.session_path,
            int(api_id),
            api_hash,
            None
        )
        self.worker.phone_required.connect(self.show_phone_dialog)
        self.worker.code_required.connect(self.show_code_dialog)
        self.worker.password_required.connect(self.show_password_dialog)
        self.worker.authorization_complete.connect(self.on_authorization_complete)
        self.worker.chat_list_loaded.connect(self.on_chat_list_loaded)
        self.worker.error.connect(self.show_error)
        self.worker.flood_wait.connect(self.handle_flood_wait)
        self.worker.start()

    def on_chat_list_loaded(self, chat_list):
        self.selected_chats = chat_list
        self.update_chats_list()
        self.chat_status.setText(f"Загружено чатов: {len(self.selected_chats)}")
        self.status_label.setText("Список чатов успешно загружен")
        self.status_label.setStyleSheet(f"color: {CURRENT_THEME['success']};")

    def update_chats_list(self):
        self.chats_list.clear()
        for chat in self.selected_chats:
            parts = chat.split(':', 1)
            chat_id = parts[0]
            chat_name = parts[1] if len(parts) > 1 else chat_id
            self.chats_list.addItem(f"{chat_name} (ID: {chat_id})")

    def clear_chats(self):
        self.selected_chats = []
        self.chats_list.clear()
        self.chat_status.setText("Чаты не выбраны. Будет произведен поиск по всем чатам.")

    def start_search(self):
        api_id = self.api_id_input.text().strip()
        api_hash = self.api_hash_input.text().strip()
        keyword = self.keyword_input.text().strip()
        
        if not api_id or not api_hash or not keyword:
            self.show_error("Пожалуйста, заполните все поля")
            return
            
        # Сброс таблицы
        self.results_table.setRowCount(0)
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.search_btn.setEnabled(False)
        self.export_csv_btn.setEnabled(False)
        self.export_txt_btn.setEnabled(False)
        self.status_label.setText("Начало авторизации...")
        self.status_label.setStyleSheet(f"color: {CURRENT_THEME['button']};")
        
        # Запуск потока
        self.worker = AsyncTelegramWorker(
            self.session_path,
            int(api_id),
            api_hash,
            keyword,
            self.selected_chats
        )
        self.worker.phone_required.connect(self.show_phone_dialog)
        self.worker.code_required.connect(self.show_code_dialog)
        self.worker.password_required.connect(self.show_password_dialog)
        self.worker.authorization_complete.connect(self.on_authorization_complete)
        self.worker.update_progress.connect(self.update_progress)
        self.worker.finished.connect(self.search_finished)
        self.worker.error.connect(self.show_error)
        self.worker.flood_wait.connect(self.handle_flood_wait)
        self.worker.start()

    def show_phone_dialog(self):
        self.phone_dialog = PhoneLoginDialog()
        self.phone_dialog.submit_btn.clicked.connect(self.process_phone)
        self.phone_dialog.exec()

    def process_phone(self):
        phone = self.phone_dialog.phone_input.text().strip()
        if phone:
            self.worker.set_phone(phone)
            self.phone_dialog.accept()
            self.status_label.setText("Отправка кода...")
        else:
            QMessageBox.warning(self, "Предупреждение", "Пожалуйста, введите номер телефона")

    def show_code_dialog(self):
        self.login_dialog = CodeLoginDialog()
        self.login_dialog.submit_btn.clicked.connect(self.process_login_code)
        self.login_dialog.exec()

    def show_password_dialog(self):
        self.login_dialog = CodeLoginDialog(is_password=True)
        self.login_dialog.submit_btn.clicked.connect(self.process_password)
        self.login_dialog.exec()

    def process_login_code(self):
        code = self.login_dialog.input_field.text().strip()
        if code:
            self.worker.set_code(code)
            self.login_dialog.accept()
            self.status_label.setText("Обработка авторизации...")
        else:
            QMessageBox.warning(self, "Предупреждение", "Пожалуйста, введите код")

    def process_password(self):
        password = self.login_dialog.input_field.text().strip()
        if password:
            self.worker.set_password(password)
            self.login_dialog.accept()
            self.status_label.setText("Обработка авторизации...")
        else:
            QMessageBox.warning(self, "Предупреждение", "Пожалуйста, введите пароль")

    def handle_flood_wait(self, seconds):
        if self.worker:
            self.worker.stop()
        self.progress_bar.setVisible(False)
        self.search_btn.setEnabled(True)
        minutes = seconds // 60
        remaining_seconds = seconds % 60
        self.status_label.setText(f"Ошибка флуда! Повторите через {minutes} мин {remaining_seconds} сек")
        self.status_label.setStyleSheet(f"color: {CURRENT_THEME['error']}; font-weight: bold;")
        QMessageBox.critical(self, "Ошибка флуда", 
                             f"Telegram ограничил запросы. Пожалуйста, подождите {minutes} минут {remaining_seconds} секунд перед повторной попыткой.")

    def on_authorization_complete(self):
        self.status_label.setText("Авторизация успешна! Начинаем поиск...")

    def update_progress(self, current, total, message):
        if total > 0:
            progress = int(current / total * 100)
            self.progress_bar.setValue(progress)
            self.progress_bar.setFormat(f"{message} ({current}/{total})")
        self.status_label.setText(message)

    def search_finished(self, results):
        self.progress_bar.setVisible(False)
        self.search_btn.setEnabled(True)
        self.export_csv_btn.setEnabled(True)
        self.export_txt_btn.setEnabled(True)
        
        # Отображение результатов
        self.results_table.setRowCount(len(results))
        for row, item in enumerate(results):
            self.results_table.setItem(row, 0, QTableWidgetItem(item['chat']))
            self.results_table.setItem(row, 1, QTableWidgetItem(str(item['sender'])))
            self.results_table.setItem(row, 2, QTableWidgetItem(item['date']))
            
            # Форматирование сообщения
            message = QTableWidgetItem(item['message'])
            message.setToolTip(item['message'])
            self.results_table.setItem(row, 3, message)
        
        self.status_label.setText(f"Поиск завершен! Найдено сообщений: {len(results)}")
        self.status_label.setStyleSheet(f"color: {CURRENT_THEME['success']}; font-weight: bold;")

    def show_error(self, message):
        if self.worker:
            self.worker.stop()
        self.progress_bar.setVisible(False)
        self.search_btn.setEnabled(True)
        self.status_label.setText(f"Ошибка: {message}")
        self.status_label.setStyleSheet(f"color: {CURRENT_THEME['error']}; font-weight: bold;")
        QMessageBox.critical(self, "Ошибка", message)

    def export_csv(self):
        filename, _ = QFileDialog.getSaveFileName(
            self, "Сохранить CSV", "xillen_results.csv", "CSV Files (*.csv)")
        if not filename:
            return
            
        try:
            with open(filename, 'w', newline='', encoding='utf-8') as file:
                writer = csv.writer(file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
                writer.writerow(['Чат', 'Отправитель', 'Дата', 'Сообщение'])
                
                for row in range(self.results_table.rowCount()):
                    chat = self.results_table.item(row, 0).text()
                    sender = self.results_table.item(row, 1).text()
                    date = self.results_table.item(row, 2).text()
                    message = self.results_table.item(row, 3).text()
                    writer.writerow([chat, sender, date, message])
                    
            QMessageBox.information(self, "Успех", f"Данные экспортированы в {filename}")
        except Exception as e:
            self.show_error(f"Ошибка экспорта: {str(e)}")

    def export_txt(self):
        filename, _ = QFileDialog.getSaveFileName(
            self, "Сохранить TXT", "xillen_results.txt", "Text Files (*.txt)")
        if not filename:
            return
            
        try:
            with open(filename, 'w', encoding='utf-8') as file:
                file.write(f"Результаты Xillen Parser\n")
                file.write(f"Сгенерировано: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                file.write(f"Ключевое слово: {self.keyword_input.text()}\n")
                file.write("-" * 80 + "\n\n")
                
                for row in range(self.results_table.rowCount()):
                    chat = self.results_table.item(row, 0).text()
                    sender = self.results_table.item(row, 1).text()
                    date = self.results_table.item(row, 2).text()
                    message = self.results_table.item(row, 3).text()
                    
                    file.write(f"Чат:    {chat}\n")
                    file.write(f"Отправитель:  {sender}\n")
                    file.write(f"Дата:    {date}\n")
                    file.write(f"Сообщение: {message}\n")
                    file.write("-" * 80 + "\n")
                    
            QMessageBox.information(self, "Успех", f"Данные экспортированы в {filename}")
        except Exception as e:
            self.show_error(f"Ошибка экспорта: {str(e)}")

    def show_tutorial(self):
        tutorial_dialog = TutorialDialog()
        tutorial_dialog.exec()

    def show_about(self):
        about_text = """
        <html>
        <head>
        <style>
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            font-size: 12pt;
            color: #2C3E50;
        }
        h1 {
            color: #6A7BFF;
            text-align: center;
        }
        .logo {
            display: block;
            margin: 0 auto;
            width: 80px;
            height: 80px;
        }
        .authors {
            font-weight: bold;
            margin-top: 15px;
        }
        .version {
            font-style: italic;
            margin-bottom: 15px;
        }
        </style>
        </head>
        <body>
        <h1>Xillen Parser</h1>
        <div class="version">Версия 1.1</div>
        <p>Мощный инструмент для поиска сообщений в Telegram по ключевым словам.</p>
        
        <div class="authors">Авторы:</div>
        <ul>
            <li><a href="https://t.me/BengaminButton">@BengaminButton</a></li>
            <li><a href="https://t.me/leshacoder">@LeshaCoder</a></li>
            <li><a href="https://t.me/xillenadapter">@XillenAdapter</a></li>
        </ul>
        
        <p>Приложение позволяет:</p>
        <ul>
            <li>Искать сообщения по ключевым словам</li>
            <li>Анализировать множество чатов одновременно</li>
            <li>Экспортировать результаты в CSV и TXT</li>
            <li>Работать в темной и светлой темах</li>
        </ul>
        </body>
        </html>
        """
        
        msg = QMessageBox(self)
        msg.setWindowTitle("О программе")
        msg.setIconPixmap(QPixmap(self.create_icon()).scaled(80, 80, Qt.AspectRatioMode.KeepAspectRatio))
        msg.setTextFormat(Qt.TextFormat.RichText)
        msg.setText(about_text)
        msg.setStandardButtons(QMessageBox.StandardButton.Ok)
        msg.exec()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    
    # Установка красивого шрифта
    font = QFont("Segoe UI", 10)
    app.setFont(font)
    
    window = XillenParser()
    window.show()
    sys.exit(app.exec())
